
package patient;
public class Patient {

 String name;
    int age;
    String gender;

    Patient(String name, int age, String gender) {
        this.name = name;
        this.age = age;
        this.gender = gender;
    }
}

class FemalePatient extends Patient {
    FemalePatient(String name, int age) {
        super(name, age, "Female");
    }

    boolean isEligible() {
        return age >= 18;
    }

    String getTreatmentLocation() {
        return isEligible() ? "Durban (DBN) Hospital" : "Not eligible for treatment";
    }
}

class MalePatient extends Patient {
    boolean hasChronicDisorder;
    MalePatient(String name, int age, boolean hasChronicDisorder) {
        super(name, age, "Male");
        this.hasChronicDisorder = hasChronicDisorder;
    }

    boolean isEligible() {
        return age >= 18;
    }

    String getTreatmentLocation() {
        if (hasChronicDisorder) {
            return "Johannesburg (JHB) Hospital";
        } else {
            return "Durban (DBN) Hospital";
        }
    }
}
